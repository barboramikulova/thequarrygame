import pygame
import sys
import random
import numpy as np
import time

# Initialize pygame
pygame.init()
pygame.mixer.init()

# Screen settings
WIDTH, HEIGHT = 1300, 750
screen = pygame.display.set_mode((WIDTH, HEIGHT))  
pygame.display.set_caption("Noise Generator")

# Define colors
colors = [(255, 0, 0), (255, 0, 240), (255, 115, 204), (0, 182, 26), (0, 255, 30), (0, 93, 50), (255, 102, 0), (225, 155, 94), (44, 0, 189)]  # Added more colors

drawing_color = colors[0]
brush_size = 8  # Slightly larger
canvas = pygame.Surface((WIDTH, HEIGHT))
canvas.fill((0, 0, 0))  

drawn_objects = []  # List to store drawn elements

# Keyboard mapping
color_keys = [pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4, pygame.K_5, pygame.K_6, pygame.K_7, pygame.K_8, pygame.K_9]

# Function to generate sound
def generate_tone(frequency, duration=0.3, sample_rate=44100, volume=2000):
    t = np.linspace(0, duration, int(sample_rate * duration), endpoint=False)
    envelope = np.exp(-3 * t)  # Softer decay
    wave = np.sin(1.1 * np.pi * frequency * t) * envelope
    samples = (wave * volume).astype(np.int16)  # Increased volume
    stereo_samples = np.column_stack((samples, samples))
    sound = pygame.sndarray.make_sound(stereo_samples)
    return sound

# Define sounds
color_sounds = {colors[i]: generate_tone(261.63 + i * 32) for i in range(len(colors))}

class DrawnObject:
    def __init__(self, color, position, size):
        self.color = color
        self.position = list(position)
        self.size = size
        self.velocity = [random.choice([-0.1, 0.1]) * random.uniform(0.1, 0.3),
                         random.choice([-0.1, 0.1]) * random.uniform(0.1, 0.3)]
    
    def move(self):
        self.position[0] += self.velocity[0]
        self.position[1] += self.velocity[1]
        if self.position[0] <= 0 or self.position[0] >= WIDTH:
            self.velocity[0] *= -1
        if self.position[1] <= 0 or self.position[1] >= HEIGHT:
            self.velocity[1] *= -1
    
    def draw(self, surface):
        pygame.draw.circle(surface, self.color, (int(self.position[0]), int(self.position[1])), self.size)

def draw_palette():
    font = pygame.font.Font(None, 24)
    for i, color in enumerate(colors):
        pygame.draw.circle(screen, color, (30, 30 + i * 50), 20)
        text = font.render(str(i + 1), True, (255, 255, 255))  
        text_rect = text.get_rect(center=(30, 30 + i * 50))  
        screen.blit(text, text_rect)

last_sound_time = 0
sound_interval = 0.3  # Default interval for sound pacing
last_mouse_pos = None

running = True
drawing = False

while running:
    screen.fill((0, 0, 0))
    screen.blit(canvas, (0, 0))
    draw_palette()
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key in color_keys:
                drawing_color = colors[color_keys.index(event.key)]
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                drawing = True
                last_mouse_pos = pygame.mouse.get_pos()
        elif event.type == pygame.MOUSEBUTTONUP:
            drawing = False
            last_mouse_pos = None
    
    if pygame.mouse.get_pressed()[0]:
        current_time = time.time()
        mouse_pos = pygame.mouse.get_pos()
        
        if last_mouse_pos:
            speed = ((mouse_pos[0] - last_mouse_pos[0]) ** 2 + (mouse_pos[1] - last_mouse_pos[1]) ** 2) ** 0.5
            sound_interval = max(0.02, min(0.4, 0.4 - speed * 0.5))  
        
        if current_time - last_sound_time > sound_interval:
            color_sounds[drawing_color].play()
            last_sound_time = current_time
        
        new_object = DrawnObject(drawing_color, mouse_pos, brush_size)
        drawn_objects.append(new_object)
        last_mouse_pos = mouse_pos
    
    for obj in drawn_objects:
        obj.move()
        obj.draw(screen)
    
    pygame.display.flip()

pygame.quit()
sys.exit()

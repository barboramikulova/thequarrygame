import pygame
import subprocess
import random
import time
import math  # Import math for sine wave

# Initialize pygame
pygame.init()

# Constants
WIDTH, HEIGHT = 800, 600
WHITE = (255, 255, 255)
ORANGE = (252, 113, 61)
START_SIZE = 50  
restplayer_START_SPEED = 2  
SPEED_INCREASE = 0.5  
MAX_ENEMIES = 10  
WIN_IMAGE_SIZE = 350  
LOSE_IMAGE_SIZE = 350  
TEXT_Y = HEIGHT // 2 - 50  
TIMER_START = 60  
WIN_COUNT = 15
LOSE_COUNT = 15 

# Fonts
font_large = pygame.font.SysFont("Times New Roman", 70)
font_small = pygame.font.SysFont("Times New Roman", 30)
font = pygame.font.SysFont("Times New Roman", 30)
small_font = pygame.font.SysFont("Times New Roman", 17)

# Load images for start screen
image_filenames = ["thequarry/assets/images/money.png", "thequarry/assets/images/rest.png", "thequarry/assets/images/poodle.png", "thequarry/assets/images/house.png"]
images = [pygame.transform.scale(pygame.image.load(img), (50, 50)) for img in image_filenames]

# Load selection images for character selection
money_image = pygame.image.load("thequarry/assets/images/money.png")
rest_image = pygame.image.load("thequarry/assets/images/rest.png")

# Scale selection images
money_image = pygame.transform.scale(money_image, (300, 300))
rest_image = pygame.transform.scale(rest_image, (300, 300))

# Load images for stoneofmoney and stoneofrest
original_moneyplayer = pygame.image.load("thequarry/assets/images/moneyplayer.PNG")  
restplayer = pygame.image.load("thequarry/assets/images/restplayer.PNG")  
original_restplayer = pygame.image.load("thequarry/assets/images/restplayer.PNG")  
moneyplayer = pygame.image.load("thequarry/assets/images/moneyplayer.PNG")
poodle = pygame.image.load("thequarry/assets/images/poodle.PNG")  
house = pygame.image.load("thequarry/assets/images/house.PNG") 
money = pygame.image.load("thequarry/assets/images/money.PNG")
rest = pygame.image.load ("thequarry/assets/images/rest.PNG")

# Scale images for stoneofmoney and stoneofrest
moneyplayer = pygame.transform.scale(original_moneyplayer, (START_SIZE, START_SIZE))
restplayer = pygame.transform.scale(original_restplayer, (START_SIZE, START_SIZE))
moneyplayer = pygame.transform.scale(moneyplayer, (START_SIZE, START_SIZE))
poodle = pygame.transform.scale(poodle, (350, 350))
money = pygame.transform.scale(money, (350, 350))
rest = pygame.transform.scale(rest, (350, 350))

# Initialize image positions and speeds
image_data = []
for i, img in enumerate(images):
    x = random.randint(0, WIDTH - 50)
    y = random.randint(0, HEIGHT - 50)
    speed_x = random.uniform(0.5, 1.5) * (1 if random.random() > 0.5 else -1)
    speed_y = random.uniform(0.5, 1.5) * (1 if random.random() > 0.5 else -1)
    image_data.append([img, x, y, speed_x, speed_y])
    image_data.append([img, x, y, speed_x, speed_y])

# Screen setup
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("The Quarry")

# Player properties (stoneofmoney and stoneofrest)
moneyplayer_x, moneyplayer_y = WIDTH // 2, HEIGHT // 2  
speed = 5  
player_x, player_y = WIDTH // 2, HEIGHT // 2  
speed = 5

# Moving objects list (stoneofmoney and stoneofrest)
restplayer_list = []
moneyplayer_list = []

# Start screen function
def start_screen():
    running = True
    while running:
        screen.fill((81, 43, 109))
        
        # Update image positions
        for data in image_data:
            if random.random() < 0.01:  # Low probability to jump
                data[1] = random.randint(0, WIDTH - 50)
                data[2] = random.randint(0, HEIGHT - 50)
            
            # Draw images
            screen.blit(data[0], (data[1], data[2]))
        
        # Render text
        title_text = font_large.render("The Quarry", True, (207, 58, 34))
        prompt_text = font_small.render("Press space to play.", True, (207, 58, 34))
        
        # Get text positions
        title_rect = title_text.get_rect(center=(WIDTH // 2, HEIGHT // 2))
        prompt_rect = prompt_text.get_rect(bottomleft=(20, HEIGHT - 20))
        
        # Draw text
        screen.blit(title_text, title_rect)
        screen.blit(prompt_text, prompt_rect)
        
        pygame.display.flip()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    character_selection()

# Character selection function
def character_selection():
    selected = None
    start_time = time.time()  # To create oscillating effect
    while selected is None:
        screen.fill((252, 113, 61))
        
        # Get the current time for the oscillation effect
        elapsed_time = time.time() - start_time
        
        # Slight up-and-down movement using sine wave
        money_y_offset = math.sin(elapsed_time * 6) * 10  # Amplitude of 10 pixels
        rest_y_offset = math.sin(elapsed_time * 2) * 10
        
        # Display images with slight vertical movement
        screen.blit(money_image, (100, 115 + money_y_offset))
        screen.blit(rest_image, (400, 115 + rest_y_offset))
        
        # Display text
        money_text1 = small_font.render("Stone of Money", True, WHITE)
        money_text2 = small_font.render("Objective: Build a stone poodle to sell.", True, WHITE)
        rest_text1 = small_font.render("Stone of Rest", True, WHITE)
        rest_text2 = small_font.render("Objective: Go home and rest.", True, WHITE)
        caption_text = font.render("Choose a character.", True, WHITE)
        
        screen.blit(money_text1, (115, 420))
        screen.blit(money_text2, (115, 440))
        screen.blit(rest_text1, (450, 420))
        screen.blit(rest_text2, (450, 440))
        screen.blit(caption_text, (20, HEIGHT - 50))
        
        pygame.display.flip()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return None
            if event.type == pygame.MOUSEBUTTONDOWN:
                x, y = pygame.mouse.get_pos()
                if 100 <= x <= 400 and 150 <= y <= 450:
                    selected = "money"
                elif 400 <= x <= 700 and 150 <= y <= 450:
                    selected = "rest"
    
    if selected == "money":
        
        def create_restplayer(speed):
            return {
                "x": random.randint(0, WIDTH - START_SIZE),
                "y": random.randint(0, HEIGHT - START_SIZE),
                "dx": random.choice([-speed, speed]),
                "dy": random.choice([-speed, speed]),
                "speed": speed,
                "size": START_SIZE  
            }

        restplayer_list.append(create_restplayer(restplayer_START_SPEED))

        touch_count = 0  # Counter for touches

        clock = pygame.time.Clock()
        running = True
        win = False
        lose = False

        # Game start sequence
        start_time = time.time()
        game_started = False
        jump_offset = 0
        jump_dir = 1

        # Add time reference for oscillation
        start_time_movement_moneyplayer = time.time()  # For moneyplayer oscillation
        start_time_movement_money = time.time()  # For money oscillation

        while running:
            screen.fill((111, 44, 22))  
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            elapsed = time.time() - start_time

            # Calculate oscillation for moneyplayer
            elapsed_movement_moneyplayer = time.time() - start_time_movement_moneyplayer
            moneyplayer_y_offset = math.sin(elapsed_movement_moneyplayer * 0) * 10  # Amplitude of 10 pixels
            
            # Calculate oscillation for money
            elapsed_movement_money = time.time() - start_time_movement_money
            money_y_offset = math.sin(elapsed_movement_money * 6) * 10  # Amplitude of 10 pixels
            
            if not game_started:
                screen.blit(money, (WIDTH // 2 - 175, HEIGHT // 2 - 170 + money_y_offset))  # Centered image with oscillation

                if elapsed < 2:
                    text = font.render("Get 15 stones of rest under a minute.", True, (255, 255, 255))
                    screen.blit(text, (20, HEIGHT - 50))
                elif elapsed < 5:
                    text1 = font.render("Build a stone poodle.", True, (255, 255, 255))
                    screen.blit(text1, (20, HEIGHT - 50))
                elif elapsed < 9:
                    text1 = font.render("Use arrow keys to move.", True, (255, 255, 255))
                    screen.blit(text1, (20, HEIGHT - 50))
                else:
                    game_started = True
                    game_start_time = time.time()

            else:
                time_left = max(0, int(TIMER_START - (time.time() - game_start_time)))
                timer_text = font.render(f"Time Left: {time_left}s", True, (255, 255, 255))
                screen.blit(timer_text, (20, HEIGHT - 50))
                
                count_text = font.render(str(touch_count), True, (255, 255, 255))
                screen.blit(count_text, (WIDTH - count_text.get_width() - 20, HEIGHT - 50))  # Adjusted for bottom-right alignment

                if time_left == 0:
                    lose = True
                    end_image = pygame.transform.scale(house, (LOSE_IMAGE_SIZE, LOSE_IMAGE_SIZE))
                    end_text = font.render("Poodle not built. Now, you rest.", True, (255, 255, 255)) 

                if not win and not lose:
                    keys = pygame.key.get_pressed()
                    global moneyplayer_x, moneyplayer_y
                    if keys[pygame.K_LEFT] and moneyplayer_x > 0:
                        moneyplayer_x -= speed
                    if keys[pygame.K_RIGHT] and moneyplayer_x < WIDTH - START_SIZE:
                        moneyplayer_x += speed
                    if keys[pygame.K_UP] and moneyplayer_y > 0:
                        moneyplayer_y -= speed
                    if keys[pygame.K_DOWN] and moneyplayer_y < HEIGHT - START_SIZE:
                        moneyplayer_y += speed

                    # Update moving objects
                    to_remove = []
                    for obj in restplayer_list:
                        obj["x"] += obj["dx"]
                        obj["y"] += obj["dy"]

                        if obj["x"] <= 0 or obj["x"] >= WIDTH - obj["size"]:
                            obj["dx"] *= -1
                        if obj["y"] <= 0 or obj["y"] >= HEIGHT - obj["size"]:
                            obj["dy"] *= -1

                        resized_restplayer = pygame.transform.scale(restplayer, (obj["size"], obj["size"]))
                        screen.blit(resized_restplayer, (obj["x"], obj["y"]))

                        if (
                            moneyplayer_x < obj["x"] + obj["size"]
                            and moneyplayer_x + START_SIZE > obj["x"]
                            and moneyplayer_y < obj["y"] + obj["size"]
                            and moneyplayer_y + START_SIZE > obj["y"]
                        ):
                            touch_count += 1  # Increase counter
                            restplayer_list.append(create_restplayer(obj["speed"] + SPEED_INCREASE))  
                            to_remove.append(obj)

                    for obj in to_remove:
                        restplayer_list.remove(obj)

                    if touch_count >= WIN_COUNT:
                        win = True
                        end_image = pygame.transform.scale(poodle, (WIN_IMAGE_SIZE, WIN_IMAGE_SIZE),)
                        end_text = font.render("Stone poodle is built.", True, (255, 255, 255))

                    if len(restplayer_list) > MAX_ENEMIES:
                        lose = True
                        end_image = pygame.transform.scale(house, (LOSE_IMAGE_SIZE, LOSE_IMAGE_SIZE))
                        end_text = font.render("Poodle not built. Now, you rest.", True, (255, 255, 255))

                    screen.blit(moneyplayer, (moneyplayer_x, moneyplayer_y + moneyplayer_y_offset))  # Added oscillation to moneyplayer

                if win:
                    screen.fill((253, 45, 230))

                if lose:
                    screen.fill((81, 43, 109))

                if win or lose:
                    screen.blit(end_text, (20, HEIGHT - 50))

                    elapsed_movement_end = time.time() - start_time_movement_moneyplayer
                    jump_offset = math.sin(elapsed_movement_end * 6) * 10  # Amplitude of 10 pixels
        

                    screen.blit(end_image, (WIDTH // 2 - WIN_IMAGE_SIZE // 2, HEIGHT // 2 - 170 + jump_offset))

            pygame.display.flip()  
            clock.tick(30)  
    elif selected == "rest":

        def create_moneyplayer(speed):
            return {
                "x": random.randint(0, WIDTH - START_SIZE),
                "y": random.randint(0, HEIGHT - START_SIZE),
                "dx": random.choice([-speed, speed]),
                "dy": random.choice([-speed, speed]),
                "speed": speed,
                "size": START_SIZE  
             }

        moneyplayer_list.append(create_moneyplayer(restplayer_START_SPEED))

        touch_count = 0  # Counter for touches

        # Collision detection
        def check_collision(obj, player_x, player_y, player_size):
            return (obj["x"] < player_x + player_size and
                    obj["x"] + obj["size"] > player_x and
                    obj["y"] < player_y + player_size and
                    obj["y"] + obj["size"] > player_y)

        clock = pygame.time.Clock()
        running = True
        win = False
        lose = False

        # Game start sequence
        start_time = time.time()
        game_started = False
        jump_offset = 0
        jump_dir = 1

        # Add time reference for oscillation
        start_time_movement_restplayer = time.time()  # For restplayer oscillation
        start_time_movement_ingamemoneybig = time.time()  # For ingamemoneybig oscillation

        while running:
            screen.fill((152, 60, 100))  
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            elapsed = time.time() - start_time

            # Calculate oscillation for restplayer
            elapsed_movement_restplayer = time.time() - start_time_movement_restplayer
            restplayer_y_offset = math.sin(elapsed_movement_restplayer * 0) * 10  # Amplitude of 10 pixels
            
            # Calculate oscillation for ingamemoneybig
            elapsed_movement_ingamemoneybig = time.time() - start_time_movement_ingamemoneybig
            ingamemoneybig_y_offset = math.sin(elapsed_movement_ingamemoneybig * 2) * 10  # Amplitude of 10 pixels

            if not game_started:
                screen.blit(rest, (WIDTH // 2 - 175, HEIGHT // 2 - 170 + ingamemoneybig_y_offset))

                if elapsed < 2:
                    text = font.render("Avoid stones of money for a minute.", True, (255, 255, 255))
                    screen.blit(text, (20, HEIGHT - 50))
                elif elapsed < 5:
                    text1 = font.render("Go home and rest.", True, (255, 255, 255))
                    screen.blit(text1, (20, HEIGHT - 50))
                elif elapsed < 9:
                    text1 = font.render("Do not collide more than 15 times.", True, (255, 255, 255))
                    screen.blit(text1, (20, HEIGHT - 50))
                elif elapsed < 12:
                    text1 = font.render("Use arrow keys to move.", True, (255, 255, 255))
                    screen.blit(text1, (20, HEIGHT - 50))
                else:
                    game_started = True
                    game_start_time = time.time()

            else:
                time_left = max(0, int(TIMER_START - (time.time() - game_start_time)))
                timer_text = font.render(f"Time Left: {time_left}s", True, (255, 255, 255))
                screen.blit(timer_text, (20, HEIGHT - 50))
                
                count_text = font.render(str(touch_count), True, (255, 255, 255))
                screen.blit(count_text, (WIDTH - count_text.get_width() - 20, HEIGHT - 50))  # Adjusted for bottom-right alignment

                # If player loses after 15 touches
                if touch_count >= LOSE_COUNT:
                    lose = True
                    end_image = pygame.transform.scale(poodle, (LOSE_IMAGE_SIZE, LOSE_IMAGE_SIZE))
                    end_text = font.render("No rest. Stone poodle is built.", True, (255, 255, 255))

                if time_left == 0 and not lose:
                    win = True
                    end_image = pygame.transform.scale(house, (WIN_IMAGE_SIZE, WIN_IMAGE_SIZE))
                    end_text = font.render("Now, you rest.", True, (255, 255, 255))

                if not win and not lose:
                    keys = pygame.key.get_pressed()
                    global player_x, player_y
                    if keys[pygame.K_LEFT] and player_x > 0:
                        player_x -= speed
                    if keys[pygame.K_RIGHT] and player_x < WIDTH - START_SIZE:
                        player_x += speed
                    if keys[pygame.K_UP] and player_y > 0:
                        player_y -= speed
                    if keys[pygame.K_DOWN] and player_y < HEIGHT - START_SIZE:
                        player_y += speed

                    # Duplicate moneyplayer every 5 seconds
                    if time.time() - game_start_time > len(moneyplayer_list) * 5:
                        moneyplayer_list.append(create_moneyplayer(restplayer_START_SPEED))

                    # Update and draw moving moneyplayer objects
                    for obj in moneyplayer_list:
                        obj["x"] += obj["dx"]
                        obj["y"] += obj["dy"]
                        if obj["x"] <= 0 or obj["x"] >= WIDTH - obj["size"]:
                            obj["dx"] *= -1
                        if obj["y"] <= 0 or obj["y"] >= HEIGHT - obj["size"]:
                            obj["dy"] *= -1
                        screen.blit(moneyplayer, (obj["x"], obj["y"]))

                        # Check if moneyplayer touches restplayer (player)
                        if check_collision(obj, player_x, player_y, START_SIZE):
                            touch_count += 1
                            moneyplayer_list.remove(obj)  # Remove the touched moneyplayer

                    screen.blit(restplayer, (player_x, player_y))

                if win:
                    screen.fill((81, 43, 109))

                if lose:
                    screen.fill((253, 45, 230))

                if win or lose:
                    screen.blit(end_text, (20, HEIGHT - 50))

                    elapsed_movement_end = time.time() - start_time_movement_restplayer
                    jump_offset = math.sin(elapsed_movement_end * 6) * 10  # Amplitude of 10 pixels
        

                    screen.blit(end_image, (WIDTH // 2 - WIN_IMAGE_SIZE // 2, HEIGHT // 2 - 170 + jump_offset))

            
            pygame.display.flip()  
            clock.tick(30)  

# Run start screen
start_screen()

pygame.quit()
